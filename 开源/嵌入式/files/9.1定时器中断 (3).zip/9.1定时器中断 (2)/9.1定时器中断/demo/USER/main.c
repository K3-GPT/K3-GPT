#include "led.h"
#include "delay.h"
#include "sys.h"

unsigned int cnt0 = 0; // ????LED0
unsigned int cnt1 = 0; // ????LED1

int main(void)
{
    delay_init();     
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 
    LED_Init();      

    // ???????????
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    // ??TIM3??
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); 

    // ?????
    TIM_TimeBaseStructure.TIM_Period = 1999;  // ???????
    TIM_TimeBaseStructure.TIM_Prescaler = 7199; // ??????
    TIM_TimeBaseStructure.TIM_ClockDivision = 0; 
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); 

    // ??TIM3????
    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

    // ??NVIC?????
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3; 
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
    NVIC_Init(&NVIC_InitStructure); 

    // ?????
    TIM_Cmd(TIM3, ENABLE); 

    // ???
    while(1)
    {
        // TIM3???????
        if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
        {
            TIM_ClearITPendingBit(TIM3, TIM_IT_Update); // ??????

            // LED1 200ms????
            cnt1++;
            if (cnt1 >= 1) // 200ms
            {
                cnt1 = 0;
                LED1 = !LED1;
            }

            // LED0 2000ms????
            cnt0++;
            if (cnt0 >= 10) // 2000ms
            {
                cnt0 = 0;
                LED0 = !LED0;
            }
        }
    }
}
