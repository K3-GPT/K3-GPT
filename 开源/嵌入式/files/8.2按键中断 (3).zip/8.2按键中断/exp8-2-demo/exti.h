#ifndef __EXTI_H
#define __EXTI_H	 
#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "key.h"

void EXTI4_IRQHandler(void);
void EXTIX_Init(void);

#endif
