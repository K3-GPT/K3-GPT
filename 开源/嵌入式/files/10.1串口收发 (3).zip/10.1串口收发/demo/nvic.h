#ifndef __NVIC_H
#define __NVIC_H	 
#include "led.h"
#include "delay.h"
#include "sys.h"
#include "misc.h"
#include "stdarg.h"

void USART_OUT(USART_TypeDef* USARTx, uint8_t *Data,...);
void uart_init(u32 bound);
char *itoa(int value, char *string, int radix);

#endif
