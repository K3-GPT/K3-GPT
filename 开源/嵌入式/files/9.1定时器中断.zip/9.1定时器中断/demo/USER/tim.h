#ifndef __TIM_H
#define __TIM_H	 
#include "led.h"
#include "delay.h"
#include "sys.h"

void TIM3_Int_Init(u16 arr,u16 psc);
void TIM3_IRQHandler(void);

#endif
