#include "led.h"
#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "key.h"

int main(void)
{	
    delay_init();	        // ???????	
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);  // ????????2
    uart_init(9600);	    // ??????9600???
    LED_Init();		    // ???LED????
    KEY_Init();		    // ?????
    LED0 = 0;		    // ??LED0
    
    // ???EXTI(????)
    EXTI_InitTypeDef EXTI_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);  // ??AFIO??,????????

    // GPIOC.5 ???????5(??????)
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource5);
    EXTI_InitStructure.EXTI_Line = EXTI_Line5;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;  // ?????
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);  // ???EXTI Line5
    
    // GPIOA.15 ???????15(??????)
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOA, GPIO_PinSource15);
    EXTI_InitStructure.EXTI_Line = EXTI_Line15;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;	
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;  // ?????
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);  // ???EXTI Line15
    
    // ??EXTI9_5????
    NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;  // ??????
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;  // ????????2
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x01;  // ????????1
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  // ????
    NVIC_Init(&NVIC_InitStructure);

    // ??EXTI15_10????
    NVIC_InitStructure.NVIC_IRQChannel = EXTI15_10_IRQn;  // ??????
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0x02;  // ????????2
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0x00;  // ????????0
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  // ????
    NVIC_Init(&NVIC_InitStructure);

    while(1)
    {	    
        printf("OK\n");	
        delay_ms(1000);  // ??1?
    } 
}
