#ifndef __TYPEHEAD_H
#define	__TYPEHEAD_H

#include "stm32f10x.h"

extern uint8_t  disp1[];

#endif

