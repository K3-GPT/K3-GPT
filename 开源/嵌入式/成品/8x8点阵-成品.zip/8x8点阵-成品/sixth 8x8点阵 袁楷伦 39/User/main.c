#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "LED.h"
#include <pt.h>
#include "Key.h"
#include "Dot_Matrix.h"
#include "Typehead.h"

/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */
int main(void)
{	
	MAX7219_GPIO_Config();
	Init_MAX7219(); 
	while (1)
	{

		Show_Num(disp1,14);
		
		OLED_Init();
		//�༶
	  OLED_ShowChinese(1, 3, 0);  
	  OLED_ShowChinese(1, 4, 1);  
	  OLED_ShowChinese(1, 5, 2);  
	  OLED_ShowChinese(1, 6, 3);  

		//���� 
		OLED_ShowChinese(2,3,4); 
	  OLED_ShowChinese(2,4,5);
	  OLED_ShowChinese(2,5,6);


		OLED_ShowChinese(3, 2, 7);  
	  OLED_ShowChinese(3, 3, 8);  
	  OLED_ShowChinese(3, 4, 9);  
	  OLED_ShowChinese(3, 5, 10);  
		OLED_ShowChinese(3, 6, 11);  
	  OLED_ShowChinese(3, 7, 12);  
	
	

	}
}





