#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

int main(void)
{
	OLED_Init();
	OLED_ShowChinese(1,1,0);
	OLED_ShowChinese(1,2,1);
	OLED_ShowChinese(1,3,2);
	OLED_ShowChinese(1,4,3);
	OLED_ShowChinese(3,3,4);
	OLED_ShowChinese(3,4,5);
	OLED_ShowChinese(3,5,6);
  OLED_ShowString(1,9,"23-2");


	
	
	
	while (1)
	{
		
	}
}
