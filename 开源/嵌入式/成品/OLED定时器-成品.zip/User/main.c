#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Key.h"
#include "Timer.h"
#include "OLED.h"
#include "stdio.h"

uint16_t i, Tim2Num, miao, shi, fen;

int main(void) {
    Key_Init();
    OLED_Init(); // ?OLED????????
    SMG_Init();
    Timer_Init();
    while (1) {
        miao = Tim2Num % 60;
        SMG_Light(0, miao % 10); // ??
        SMG_Light(1, miao / 10); // ??
        fen = Tim2Num % 3600 / 60;
        SMG_Light(2, fen % 10); // ??
        SMG_Light(3, fen / 10); // ??
        shi = Tim2Num % (24 * 3600) / 3600;

        char timeStr[9];
        sprintf(timeStr, "%02d:%02d:%02d", shi, fen, miao);
        OLED_ShowString(1, 4, timeStr); // ??(0,0)?OLED???????

        // ??????,??1?
        Delay_s(1);
        OLED_ShowChinese(2, 4, 0);
        OLED_ShowChinese(2, 5, 1);
        OLED_ShowChinese(2, 6, 2);
        OLED_ShowNum(4,4,2304115226,10);
    }
}

// TIM2??????
void TIM2_IRQHandler(void) {
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET) { // ??TIM2????
        Tim2Num++;
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update); // ??TIM2????
    }
}

#include "stm32f10x.h"                  // Device header
#include "Delay.h"

// 5461BS-1?????
u16 seg[] = {0xc0, 0xf9, 0xa4, 0xb0, 0x99, 0x92, 0x82, 0xf8, 0x80, 0x90}; // 0-9

extern u16 tim4Cnt;

void SMG_Init(void) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE); // ??GPIOA?GPIOB??

    // ???GPIOA
    GPIO_InitTypeDef GPIO_InitStructureA;
    GPIO_InitStructureA.GPIO_Pin = GPIO_Pin_All;
    GPIO_InitStructureA.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructureA.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructureA);

    // ???GPIOB
    GPIO_InitTypeDef GPIO_InitStructureB;
    GPIO_InitStructureB.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
    GPIO_InitStructureB.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructureB.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructureB);

    GPIO_SetBits(GPIOB, GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15);
}

void SMG_clean(void) {
    GPIO_Write(GPIOB, 0x0000); // ????GPIOB??
    Delay_ms(2);
}

// ?????,??w,??num
void SMG_Light(uint16_t w, uint16_t num) {
    SMG_clean();
    switch (w) {
        case 0:
			GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_SET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_13,Bit_RESET);		
			GPIO_WriteBit(GPIOB,GPIO_Pin_14,Bit_RESET);	
            break;
        case 1:
			GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_SET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_13,Bit_RESET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_14,Bit_RESET); 
            break;
        case 2:
			GPIO_WriteBit(GPIOB,GPIO_Pin_13,Bit_SET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET);		
			GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);			
			GPIO_WriteBit(GPIOB,GPIO_Pin_14,Bit_RESET);	           
			break;
        case 3:
			GPIO_WriteBit(GPIOB,GPIO_Pin_14,Bit_SET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET);			
			GPIO_WriteBit(GPIOB,GPIO_Pin_13,Bit_RESET);			
			GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);	
            break;
        default:
            SMG_clean(); // ??????,????????
            return;
    }
    GPIO_Write(GPIOA, seg[num]); // ???????
    Delay_ms(2);
};
