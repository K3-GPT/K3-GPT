#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Key.h"
#include "Timer.h"
#include "OLED.h"
uint16_t i,Tim2Num,miao,shi,fen;
void SMG_Init(void);  
void SMG_Light(uint16_t w, uint16_t num);  
void OLED_Display_Init(void); 

int main(void){
	Key_Init();
	SMG_Init();
	Timer_Init();
	OLED_Init();
	
	while(1){
		miao=Tim2Num%60;
		SMG_Light(0,miao%10);//ge ��λ
		SMG_Light(1,miao/10);//shi ʮλ
		fen=Tim2Num%3600/60;
		SMG_Light(2,fen%10);//ge
		SMG_Light(3,fen/10);//shi
		shi=Tim2Num%(24*3600)/3600;//Сʱ 
	}
}

void TIM2_IRQHandler(void){
	if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET){
		Tim2Num++;
	  OLED_ShowNum(1,5,shi,2);
	  OLED_ShowString(1,7,":");
	  OLED_ShowNum(1,8,fen,2);
	  OLED_ShowString(1,10,":");
	  OLED_ShowNum(1,11,miao,2);
	  OLED_ShowChinese(2, 3, 0);  
	  OLED_ShowChinese(2, 4, 1);  
	  OLED_ShowChinese(2, 5, 2);  
	  OLED_ShowChinese(2, 6, 3);  
		OLED_ShowChinese(3,3,4);
		OLED_ShowChinese(3,4,5);
		OLED_ShowChinese(3,5,6);
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);

	}
}
//2204115116��


#include "stm32f10x.h"                  // Device header
#include "Delay.h"
 
//5461BS-1????
u16 seg[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};//?? ���������ӵ����ص�����
//u16 seg[] = {0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};//??������
 
extern u16 tim4Cnt;
 
void SMG_Init(void){
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE); //??GPIOA?????
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	//??????
	GPIO_InitTypeDef GPIO_InitStructureA;//???????
	GPIO_InitStructureA.GPIO_Pin=GPIO_Pin_All;  //???????IO? all ȫ������ʹ��
	GPIO_InitStructureA.GPIO_Mode=GPIO_Mode_Out_PP;	 //????????�������ģʽ
	GPIO_InitStructureA.GPIO_Speed=GPIO_Speed_50MHz;	  //???????50MHZ
	GPIO_Init(GPIOA,&GPIO_InitStructureA); 	   /* ???GPIO */
	
	//??????
	GPIO_InitTypeDef GPIO_InitStructureB;//???????
	GPIO_InitStructureB.GPIO_Pin=GPIO_Pin_All;  //???????IO?
	GPIO_InitStructureB.GPIO_Mode=GPIO_Mode_Out_PP;	 //????????
	GPIO_InitStructureB.GPIO_Speed=GPIO_Speed_50MHz;	  //???????50MHZ
	GPIO_Init(GPIOB,&GPIO_InitStructureB); 	   /* ???GPIO */
	
	GPIO_SetBits(GPIOA,GPIO_Pin_All);
}
 
void SMG_clean(){
	GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);
	GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET);			
	GPIO_WriteBit(GPIOB,GPIO_Pin_13,Bit_RESET);			
	GPIO_WriteBit(GPIOB,GPIO_Pin_14,Bit_RESET);	
	Delay_ms(2);
}
 
//???w?,????num
void SMG_Light(uint16_t w,uint16_t num){//����
	SMG_clean();
	//??
	switch(w){//case ���������4��
		case 0:
			GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_SET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_13,Bit_RESET);		
			GPIO_WriteBit(GPIOB,GPIO_Pin_14,Bit_RESET);	
			break;
		case 1:
			GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_SET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_13,Bit_RESET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_14,Bit_RESET);
			break;
		case 2:
			GPIO_WriteBit(GPIOB,GPIO_Pin_13,Bit_SET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET);		
			GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);			
			GPIO_WriteBit(GPIOB,GPIO_Pin_14,Bit_RESET);	
			break;
		case 3:
			GPIO_WriteBit(GPIOB,GPIO_Pin_14,Bit_SET);
			GPIO_WriteBit(GPIOB,GPIO_Pin_12,Bit_RESET);			
			GPIO_WriteBit(GPIOB,GPIO_Pin_13,Bit_RESET);			
			GPIO_WriteBit(GPIOB,GPIO_Pin_0,Bit_RESET);	
			break;//����ѭ��
	}
	//??
	GPIO_Write(GPIOA,seg[num]);
	Delay_ms(2);
}
 