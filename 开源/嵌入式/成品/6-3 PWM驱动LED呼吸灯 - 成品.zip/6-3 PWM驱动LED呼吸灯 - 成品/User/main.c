#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "PWM.h"

uint8_t i;			//定义for循环的变量

int main(void)
{
    /*模块初始化*/
    OLED_Init();        //OLED初始化
    PWM_Init();            //PWM初始化
    
    while (1) {
        // 两个灯同时逐渐变亮
        for (uint8_t i = 0; i <= 100; i++) {
            PWM_SetCompare1(i); // 设置绿灯亮度逐渐增加
            PWM_SetCompare2(i); // 设置红灯亮度逐渐增加
            Delay_ms(10);       // 延时10毫秒
        }

        // 两个灯同时保持最亮1秒
        Delay_ms(1000);       // 延时1秒

        // 两个灯同时逐渐变暗
        for (uint8_t i = 100; i > 0; i--) {
            PWM_SetCompare1(i); // 设置绿灯亮度逐渐减少
            PWM_SetCompare2(i); // 设置红灯亮度逐渐减少
            Delay_ms(10);       // 延时10毫秒
        }

        // 两个灯同时熄灭1秒
        Delay_ms(1000);       // 延时1秒

        // 以下代码显示OLED屏幕上的内容
        OLED_ShowChinese(1, 2, 0);
        OLED_ShowChinese(1, 3, 1);
        OLED_ShowChinese(1, 4, 2);
        OLED_ShowChinese(1, 5, 3);

        OLED_ShowChinese(2, 3, 4);
        OLED_ShowChinese(2, 4, 5);
        OLED_ShowChinese(2, 5, 6);

        OLED_ShowString(1, 11, "23-2");
        OLED_ShowString(3, 4, "2304115205");
    }
}
