#include "stm32f10x.h"                  // Device header

/**
  * 函    数：PWM初始化
  * 参    数：无
  * 返 回 值：无
  */
void PWM_Init(void)
{
    /*开启时钟*/
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);            // TIM2 时钟
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);            // GPIOA 时钟

    /*GPIO初始化*/
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;   // 复用推挽输出模式
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    // 配置 PA0 作为绿灯
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 配置 PA1 作为红灯
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /*配置时钟源*/
    TIM_InternalClockConfig(TIM2);

    /*时基单元初始化*/
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;    
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up; 
    TIM_TimeBaseInitStructure.TIM_Period = 100 - 1;                 // ARR
    TIM_TimeBaseInitStructure.TIM_Prescaler = 720 - 1;              // 50kHz
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;            
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

    /*输出比较初始化 - 通道1 (绿灯)*/
    TIM_OCInitTypeDef TIM_OCInitStructure;
    TIM_OCStructInit(&TIM_OCInitStructure);
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;              
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;     
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
    TIM_OCInitStructure.TIM_Pulse = 0;                            
    TIM_OC1Init(TIM2, &TIM_OCInitStructure);                     

    /*输出比较初始化 - 通道2 (红灯)*/
    TIM_OCInitStructure.TIM_Pulse = 0;                            // 初始值为 0
    TIM_OC2Init(TIM2, &TIM_OCInitStructure);                      // TIM2 通道 2

    /*TIM使能*/
    TIM_Cmd(TIM2, ENABLE);
}


/**
  * 函    数：PWM设置CCR
  * 参    数：Compare 要写入的CCR的值，范围：0~100
  * 返 回 值：无
  * 注意事项：CCR和ARR共同决定占空比，此函数仅设置CCR的值，并不直接是占空比
  *           占空比Duty = CCR / (ARR + 1)
  */
void PWM_SetCompare1(uint16_t Compare)
{
	TIM_SetCompare1(TIM2, Compare);		//设置CCR1的值
}

void PWM_SetCompare2(uint16_t Compare)
{
    TIM_SetCompare2(TIM2, Compare);     // 设置 PA1 (红灯) 的占空比
}
