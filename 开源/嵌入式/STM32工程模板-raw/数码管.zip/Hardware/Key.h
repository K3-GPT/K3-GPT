#ifndef __KEY_H
#define __KEY_H

void Key_Init(void);
uint8_t Key_GetNum(void);
void SMG_Init(void);
void SMG_Light(uint16_t w,uint16_t num);
void SMG_Init(void);

#endif
