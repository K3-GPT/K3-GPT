#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "LED.h"
#include <pt.h>
#include "Key.h"
#include "Dot_Matrix.h"
#include "Typehead.h"

/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */
int main(void)
{	
	MAX7219_GPIO_Config();
	Init_MAX7219(); 
	while (1)
	{

		Show_Num(disp1,5);

	}
}





