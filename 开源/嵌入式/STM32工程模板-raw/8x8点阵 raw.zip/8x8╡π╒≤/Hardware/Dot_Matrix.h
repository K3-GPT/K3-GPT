#ifndef __DOT_MATRIX_H
#define	__DOT_MATRIX_H

#include "stm32f10x.h"

//����Max7219�˿�
#define DIN_GPIO_PORT    	GPIOA		              /* GPIO�˿� */
#define DIN_GPIO_CLK 	    RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */
#define DIN_GPIO_PIN			GPIO_Pin_1			        

#define CS_GPIO_PORT    	GPIOA			              /* GPIO�˿� */
#define CS_GPIO_CLK 	    RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */
#define CS_GPIO_PIN		    GPIO_Pin_2			        

#define CLK_GPIO_PORT    	GPIOA			              /* GPIO�˿� */
#define CLK_GPIO_CLK 	    RCC_APB2Periph_GPIOA		/* GPIO�˿�ʱ�� */
#define CLK_GPIO_PIN		  GPIO_Pin_3			 

#define DIN_1    	GPIO_SetBits(DIN_GPIO_PORT, DIN_GPIO_PIN)
#define DIN_0    	GPIO_ResetBits(DIN_GPIO_PORT, DIN_GPIO_PIN)

#define CS_1    	GPIO_SetBits(CS_GPIO_PORT, CS_GPIO_PIN)
#define CS_0    	GPIO_ResetBits(CS_GPIO_PORT, CS_GPIO_PIN)

#define CLK_1    	GPIO_SetBits(CLK_GPIO_PORT, CLK_GPIO_PIN)
#define CLK_0    	GPIO_ResetBits(CLK_GPIO_PORT, CLK_GPIO_PIN)
	
void Init_MAX7219(void);
void Write_Max7219(uint8_t address1,uint8_t dat1);
void MAX7219_GPIO_Config(void);
void Show_Num(uint8_t *Num,uint8_t Long);	
#endif




