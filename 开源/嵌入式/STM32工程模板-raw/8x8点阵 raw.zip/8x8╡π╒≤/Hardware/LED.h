#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void LED_ON(int i);
void LED_OFF(int i);
void LED(int i);
#endif
